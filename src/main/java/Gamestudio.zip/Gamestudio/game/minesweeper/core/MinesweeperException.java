package Gamestudio.game.minesweeper.core;

public class MinesweeperException extends Exception  {
	public MinesweeperException (String message) {
        super ("!");
    }
}
