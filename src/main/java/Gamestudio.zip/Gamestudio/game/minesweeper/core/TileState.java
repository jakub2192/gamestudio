package Gamestudio.game.minesweeper.core;

public enum TileState {
	OPEN,CLOSED,MARKED

}
