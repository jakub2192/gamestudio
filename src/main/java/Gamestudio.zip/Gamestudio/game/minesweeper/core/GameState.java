package Gamestudio.game.minesweeper.core;

public enum GameState {
	PLAYING,SOLVED,FAILED

}
