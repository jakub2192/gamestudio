package Gamestudio.game.minesweeper.core;

public class Mine extends Tile{

}
